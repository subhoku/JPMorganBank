package com.codeo.diamondsol;

public interface MobileGame {
	
	default public void weekendSpecial() {
		System.out.println("Weekend special mobile games");
	}

}
