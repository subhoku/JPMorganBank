package com.codeo.interface1;

abstract public class Car implements Vehicle {
 public void breaks() {
	 System.out.println("Breaks for Car");
 }
}
