package com.codeo.interface1;

public class Runner {

	public static void main(String[] args) {
    Vehicle v=new Bus();
    v.breaks();
    v.engine();
     
	}

}
