package com.codeo.interface1;



public class Truck implements Vehicle {

	@Override
	public void engine() {
	System.out.println("high power truck engine");
		
	}

	@Override
	public void breaks() {
		System.out.println("Combi break for trucks");
		
	}

	

}
