package com.codeo.interface1;

public interface Vehicle {

	void engine();
	void breaks();
}
