package com.codeo.accessmodifier;

 class Sample1  {

	
public static void main(String[] args) {
	ProtectedExample pe=new ProtectedExample();
	System.out.println(pe.a+" "+pe.str);
	
}
}
