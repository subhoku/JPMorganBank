package com.codeo.collect;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Basic {
	
	int sno;
	String studentname;
	double percent;
	
	ArrayList<String> arr;
	
	

	public Basic(List<String> lis) {
		super();
		this.arr = lis;
		System.out.println("Constructor");
	}


	public Basic(int sno, String studentname, double percent) {
		super();
		this.sno = sno;
		this.studentname = studentname;
		this.percent = percent;
	}
	
	public void ListPrint() {
		for(String s:arr) {
			System.out.println(s);
		}
	}


	public static void main(String[] args) {

		//Collection==> FrameWork
		//Collections==>Class in Java
		//List==> Interface
		//ArrayList==> Class
		//Generics Concept==> Integer, String, double, Object
		//jdk 1.7==> jdk 1.8
		//arr[5]==>arr[50]
		
		List<String> list=new ArrayList<>();
		
		list.add("codeo");
	
		list.add("sudarshan");
		list.add("graph");
		list.add(0, "Aakash");
		list.remove(3);
		list.add("Aakash");
		List<String> lis=new ArrayList<String>(list);
         Basic b=new Basic(lis);
		System.out.println(list);
		try {
			Collections.sort(list);
		}
		catch(NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("Sorted List will be: "+list);
		//Incremented by 50%
		//arr[50]={1,2,3,4,5,6}==>44 
		for(String l:list) {
			System.out.println(l);
		}
		
		List<Integer> list1=new ArrayList<>();
		list1.add(3);
		list1.add(6);
		list1.add(1);
		System.out.println(list1);
		//Incremented by 50%
		//arr[50]={1,2,3,4,5,6}==>44 
		for(int l:list1) {
			System.out.println(l);
		}
		//Object type list
		//class name as generics
		List<Basic> forobject=new ArrayList<>();
		/*
		 * Basic b1=new Basic(11,"sudarshan",67.34); Basic b2=new
		 * Basic(12,"Harshita",45.76);
		 */
		forobject.add(new Basic(11,"sudarshan",67.34));
		forobject.add(new Basic(12,"Akshay",77.34));
		
		
		for(Basic b:forobject) {
			System.out.println(b.sno+" "+b.studentname+" "+b.percent);
		}
		

}


	
}