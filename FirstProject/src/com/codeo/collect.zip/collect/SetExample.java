package com.codeo.collect;

import java.util.HashSet;
import java.util.Set;

public class SetExample {

	public static void main(String[] args) {
		//Set is Interface
		//HashSet is class
		//Set can involve Null object
		//Set Never involved Duplicate Object
		Set<String> str=new HashSet<>();
		str.add(null);
		str.add("codeo");
		str.add("graph");
		str.add("solutions");
		str.add("building");
		str.add("solutions");
		str.add("building");
		str.add("infinite");
		System.out.println(str);
		Set<SetExample> hs=new HashSet<>();
		hs.add(new SetExample());
		hs.add(new SetExample());
		hs.add(new SetExample());
		//
		System.out.println(hs);

		Set<Integer> s=new HashSet<>();
		s.add(1);
		s.add(3);
		s.add((int) 0.0);
		s.add(Integer.parseInt("23"));
		s.add(null);
		System.out.println(s);
	}

}
